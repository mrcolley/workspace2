import { AnimalImageDirective } from './animal-image.directive';

describe('AnimalImageDirective', () => {
  it('should create an instance', () => {
    const directive = new AnimalImageDirective();
    expect(directive).toBeTruthy();
  });
});
